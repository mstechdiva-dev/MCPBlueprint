# Contributing to MCPBlueprint

Thanks for your interest in contributing. This project grows through community input — new agent patterns, better definitions, improved templates, and real-world examples all make it more useful for everyone.

---

## What You Can Contribute

- **New agent type definitions** — if you've identified a pattern not covered by the existing 9
- **Improvements to existing definitions** — clearer explanations, better examples, corrected details
- **New templates** — starter configs for platform types not yet covered
- **New examples** — real-world reference architectures (keep them generic, no proprietary details)
- **Risk scanner rules** — additional rules for the scanner's rule set
- **Bug fixes** — broken links, incorrect config examples, outdated instructions

---

## How to Submit

1. Fork the repo
2. Create a branch named for your change: `add-streaming-agent-pattern` or `fix-guardrail-config-example`
3. Make your changes
4. Open a pull request with a clear description of what you changed and why
5. A maintainer will review and respond

---

## Agent Definition Standards

If you're adding a new agent type, your folder must include:

- `definition.md` — what the agent does, when to use it, when not to use it
- `config.example.json` — a working example configuration with comments
- `test.md` — how to verify the agent is working correctly

Follow the format of existing agent folders for consistency.

---

## What We Won't Merge

- Definitions that reference specific proprietary platforms or services by name
- Integrations built into the core framework (suggest patterns, don't wire things up)
- Anything that removes the modular opt-in nature of the system
- Config examples with hardcoded credentials or real API keys

---

## Questions

Open an issue and tag it `question`. We'd rather you ask than guess.
