# MCPBlueprint Overview

## What This Is

MCPBlueprint is a framework for defining, building, testing, and managing MCP agents in a structured, repeatable way. It is not a runtime engine — it is a blueprint system. It tells you what each agent type is, how to configure it, how to test it, and how to protect it.

The core idea is that most teams building with agents face the same problems:
- No consistent way to define what an agent is supposed to do
- No clear guardrails on what it should not do
- No scan of actual risk before deploying
- No easy way to turn agents on or off without touching code

MCPBlueprint solves all four.

---

## How It Works

### Step 1 — Onboarding Prompts
When you set up MCPBlueprint for the first time, a short prompt flow asks questions about your platform. What kind of data does it handle? What external APIs does it call? Does it process user PII? Those answers auto-fill a base configuration specific to your project.

### Step 2 — Risk Scanner
Before your guardrail agent is configured, the risk scanner runs against your codebase or config files. It identifies real exposure areas — data paths, API scopes, auth patterns, potential loop conditions — and produces a risk profile in JSON format.

### Step 3 — Guardrail Generation
The risk profile from the scanner becomes the source material for your guardrail agent's rules. You are not writing rules from scratch based on what you think might be risky. The scanner tells you what is actually at risk, and the guardrail agent is built around those findings.

### Step 4 — Agent Activation
Using the admin panel, you activate the agents your platform needs. Each agent is modular. Nothing is forced on. You can add or remove agents as your platform evolves without rebuilding your configuration from scratch.

### Step 5 — Testing
Each agent folder includes a test.md file with specific steps to verify the agent is working as expected. Run through the checklist before going live.

---

## What MCPBlueprint Is Not

- It is not a hosted service
- It is not an integration platform — it does not wire up GitHub, Slack, or any external tool for you
- It is not a runtime that executes agent logic for you
- It is not opinionated about your tech stack

It is a structured reference system you drop into your project and adapt to your needs.

---

## Repo Structure

```
MCPBlueprint/
│
├── README.md                          # Project overview and quick start
├── CONTRIBUTING.md                    # How to contribute
├── LICENSE                            # MIT
│
├── /docs                              # Documentation
│   ├── overview.md                    # This file
│   ├── getting-started.md             # Setup walkthrough
│   ├── agent-activation.md            # How to activate and deactivate agents
│   └── risk-scanner.md                # How the scanner works
│
├── /agents                            # One folder per agent type
│   ├── /direct-api-wrapper
│   ├── /composite-service
│   ├── /mcp-to-agent
│   ├── /event-driven
│   ├── /configuration-use
│   ├── /analytics-data-access
│   ├── /hierarchical-mcp
│   ├── /local-resource-access
│   └── /guardrail
│
├── /risk-scanner                      # Risk scanner agent
│   ├── README.md
│   ├── scanner.md
│   ├── output-schema.md
│   └── /rules
│
├── /admin-panel                       # Agent management UI
│   ├── README.md
│   ├── features.md
│   └── upload-spec.md
│
├── /templates                         # Starter configs by platform type
│
└── /examples                          # Reference architectures
```
