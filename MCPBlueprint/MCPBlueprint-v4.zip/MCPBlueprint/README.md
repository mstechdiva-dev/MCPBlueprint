# MCPBlueprint

> MCPBlueprint tells a story where agents are the main characters and your data is the backstory. The risk scanner reads that backstory before anything starts. The guardrail watches every character to make sure no one goes off script.

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](CONTRIBUTING.md)
[![Status: Active](https://img.shields.io/badge/Status-Active-green.svg)]()

---

## The Problem

Most teams building with MCP agents run into the same wall: there is no consistent way to define what an agent should do, no clear boundary on what it should not do, and no structured process for identifying risk before something goes wrong.

You end up with agents that are hard to reason about, configurations that drift over time, and guardrails that are either missing entirely or built around guesses rather than actual findings.

MCPBlueprint solves this by giving you a structured starting point — not a rigid system — that grows with your platform.

---

## How It Works

MCPBlueprint is not a runtime. It is a blueprint system: a set of well-defined agent patterns, an onboarding flow that generates configuration from your answers, a risk scanner that identifies real exposure areas in your codebase, and an admin panel that puts everything under one roof.

```
Answer onboarding prompts
        ↓
Config auto-generated for your platform
        ↓
Risk scanner runs against your codebase
        ↓
Guardrail rules built from scan findings
        ↓
Activate only the agents you need
        ↓
Admin panel manages everything from one place
```

The guardrail agent is the centerpiece. Its rules come from what the scanner actually found in your project — not from a generic checklist you fill in by hand. A developer who does not know what is at risk gets a guardrail that does.

---

## What's Included

### 9 Agent Types

Every agent type is defined in plain markdown — what it does, when to use it, when not to, how to configure it, and how to test it. Each one is self-contained and independently activatable.

| # | Agent | Purpose |
|---|-------|---------|
| 1 | [Direct API Wrapper](agents/direct-api-wrapper/definition.md) | Clean single-API connections with no intermediary |
| 2 | [Composite Service](agents/composite-service/definition.md) | Unify multiple APIs into a single coordinated call |
| 3 | [MCP-to-Agent](agents/mcp-to-agent/definition.md) | Trigger specialized sub-agents based on output routing |
| 4 | [Event-Driven](agents/event-driven/definition.md) | React to event streams in real time |
| 5 | [Configuration Use](agents/configuration-use/definition.md) | Self-tuning agent behavior based on context signals |
| 6 | [Analytics Data Access](agents/analytics-data-access/definition.md) | Pull trend and metrics data for informed decisions |
| 7 | [Hierarchical MCP](agents/hierarchical-mcp/definition.md) | Coordinate multiple domain-specific agents |
| 8 | [Local Resource Access](agents/local-resource-access/definition.md) | Secure, scoped access to local files and resources |
| 9 | [Guardrail](agents/guardrail/definition.md) | Monitor and protect all other agents in real time |

### Risk Scanner

A standalone agent that runs before your guardrail is configured. It scans your codebase across four categories — data exposure, API scope, auth patterns, and loop detection — and produces a structured risk profile. That profile becomes the source for your guardrail's rule set.

### Admin Panel

A local web interface for managing active agents, reviewing guardrail alerts, uploading updated agent definitions, and viewing your current risk profile — without touching config files directly.

### Onboarding Prompt Flow

An 11-question flow that asks about your platform's data sensitivity, external connections, processing model, and preferences. Your answers auto-generate a `config/platform.json` and recommend which agents and templates are the best fit for your use case.

### Templates

Starter configurations for four common platform types:
- [Minimal Setup](templates/minimal-setup.md) — get running with the least possible footprint
- [API-Heavy Platform](templates/api-platform.md) — multiple external API connections
- [Data Pipeline](templates/data-pipeline.md) — real-time ingestion and processing
- [Sensitive Data Platform](templates/hr-sensitive.md) — PII, regulated data, compliance-adjacent use cases

### Examples

Three generic reference architectures showing how different platform types wire agents together, what configuration decisions matter most, and what the risk scanner typically finds for each type:
- [Real-Time Data Platform](examples/real-time-data-platform.md)
- [Sensitive Data Processing Platform](examples/sensitive-data-platform.md)
- [API Monitoring Platform](examples/api-monitoring-platform.md)

---

## Quick Start

**Prerequisites:** Node.js 18 or higher

**1. Clone the repo**
```bash
git clone https://github.com/your-org/MCPBlueprint.git
cd MCPBlueprint
npm install
```

**2. Run the onboarding prompt flow**
```bash
node admin-panel/onboarding.js
```
Answer the questions about your platform. Your config is generated automatically at `config/platform.json`.

**3. Run the risk scanner**
```bash
node risk-scanner/scanner.js --target /path/to/your/project
```
Output saved to `risk-scanner/output/risk-profile.json`. Review the findings before continuing.

**4. Start the admin panel**
```bash
node admin-panel/index.js
```
Opens at `http://localhost:3000`. Activate agents, review alerts, and manage your setup from here.

**5. Test each active agent**

Every agent folder includes a `test.md` checklist. Work through it for each agent you activated before going to production.

---

## Repo Structure

```
MCPBlueprint/
│
├── README.md                          # You are here
├── CONTRIBUTING.md                    # How to contribute
├── LICENSE                            # MIT
│
├── docs/
│   ├── overview.md                    # Full system overview
│   ├── getting-started.md             # Detailed setup walkthrough
│   ├── agent-activation.md            # How to activate and manage agents
│   ├── risk-scanner.md                # How the scanner works
│   ├── tool-design.md                 # How to design tools agents actually use correctly
│   ├── auth-patterns.md               # Bearer token, OAuth, and scoped data access
│   └── production.md                  # Health checks, logging, audit trails, deployment
│
├── agents/                            # One folder per agent type
│   ├── direct-api-wrapper/
│   ├── composite-service/
│   ├── mcp-to-agent/
│   ├── event-driven/
│   ├── configuration-use/
│   ├── analytics-data-access/
│   ├── hierarchical-mcp/
│   ├── local-resource-access/
│   └── guardrail/                     # Always activate this first
│
├── risk-scanner/
│   ├── README.md
│   ├── output-schema.md
│   ├── output/                        # Generated risk profile lands here
│   └── rules/                         # Four rule category files
│
├── admin-panel/
│   ├── README.md
│   ├── features.md
│   ├── upload-spec.md
│   └── onboarding-prompts.md          # Full question set and mapping
│
├── templates/                         # Starter configs by platform type
│
└── examples/                          # Reference architectures
```

---

## Core Principles

**Guardrails from real findings, not guesswork.**
The guardrail agent's rules are generated from what the risk scanner actually found in your project. You do not write rules by hand based on what you think might be at risk. The scanner tells you what is.

**Markdown as the source of truth.**
Every agent definition is plain markdown. No proprietary formats, no tooling lock-in. Anyone can read it, fork it, edit it, and contribute back with nothing more than a text editor.

**Modular and opt-in.**
Nothing is forced on. You activate what your platform needs and leave off what it does not. Each agent is self-contained — definition, config, and test checklist all in one folder. Removing an agent means setting one value to false.

**No forced integrations.**
MCPBlueprint does not wire up GitHub, Slack, Jira, or any external service. It documents how you would approach those integrations if you need them and leaves the implementation to your platform.

**Start with alert, grow into intervene.**
The guardrail agent runs in two modes: alert (log and notify) and intervene (block and act). The recommendation is to start with alert mode, validate your rule set over a few weeks, and then graduate to intervene once you have confidence in your thresholds.

---

## Guardrail Agent

The guardrail is the most important agent in the framework. It should be the first one activated and the last one deactivated.

| Mode | Behavior |
|------|----------|
| `alert` | Logs suspicious activity and sends notifications. Nothing is automatically stopped. Recommended starting point. |
| `intervene` | Can pause, block, or reroute another agent mid-task when a rule is triggered. Use after validating alert mode. |

**Baseline rules active on every platform:**
- Log all agent-to-agent handoffs with timestamps
- Alert on silent failures (unhandled exceptions that do not surface an error)
- Flag repeated identical failed calls (loop or broken dependency indicator)
- Alert on scope violations (agent accessing a resource outside its defined boundaries)
- Block credential or token exposure in output payloads
- Alert on unexpected agent activations

See [agents/guardrail/definition.md](agents/guardrail/definition.md) for the full reference.

---

## Risk Scanner

The scanner checks four categories:

| Category | What It Looks For |
|----------|--------------------|
| Data Exposure | PII in payloads, credentials in output, unvalidated write paths |
| API Scope | Overly broad permissions, calls to unlisted endpoints, hardcoded keys |
| Auth Patterns | Missing auth gates, admin access without role checks, bypassable sessions |
| Loop Detection | Unbounded retries, circular agent dependencies, cascading event triggers |

```bash
node risk-scanner/scanner.js --target /path/to/your/project --verbose
```

Output format documented in [risk-scanner/output-schema.md](risk-scanner/output-schema.md).

---

## Contributing

Contributions are welcome. The most useful things to add:
- New agent type definitions for patterns not covered by the existing 9
- Improvements to existing definitions — clearer explanations, better examples
- New templates for platform types not yet covered
- Additional risk scanner rules

See [CONTRIBUTING.md](CONTRIBUTING.md) for standards, submission process, and what will not be merged.

---

## Roadmap

MCPBlueprint is community driven. There is no fixed release schedule. Areas where contributions would have the most impact:
- Scanner rule expansion for cloud-native and serverless architectures
- Additional platform templates
- Admin panel implementation (currently documented as a spec — implementation contributions welcome)
- Testing frameworks for agent validation

Open an issue to discuss before building anything large.

---

## Questions

Open an issue. Tag it `question` for general questions, `bug` for something broken, or `new-agent` to propose a new agent type.

---

## License

MIT — use it, fork it, build on it. See [LICENSE](LICENSE) for the full text.
