# Admin Panel

The MCPBlueprint admin panel is the control surface for managing your agents. It runs locally and gives you visibility into what is active, what has been flagged, and what your current configuration looks like — without touching config files directly.

## Starting the Panel

```bash
node admin-panel/index.js
```

Runs at `http://localhost:3000` by default.

## What You Can Do From the Panel

See [features.md](features.md) for the full feature list.

## Uploading Markdown Files

Agent definitions can be updated by uploading new markdown files through the panel. See [upload-spec.md](upload-spec.md) for the expected format and what gets updated when you upload.

## Security Note

The admin panel is intended for local use only. Do not expose it publicly without adding authentication. No auth is included by default — this is intentional to keep the setup simple, but it means you are responsible for securing access if you run it anywhere other than localhost.
