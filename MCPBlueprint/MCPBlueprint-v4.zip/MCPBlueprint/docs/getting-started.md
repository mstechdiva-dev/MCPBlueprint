# Getting Started with MCPBlueprint

## Prerequisites

- Node.js 18 or higher
- Access to the codebase or config files you want the risk scanner to analyze
- A basic understanding of what your platform does and what data it handles

---

## Step 1 — Clone the Repo

```bash
git clone https://github.com/your-org/MCPBlueprint.git
cd MCPBlueprint
npm install
```

---

## Step 2 — Run the Onboarding Prompts

The onboarding flow asks questions about your platform and uses your answers to generate a base configuration file. This takes about 5 minutes.

```bash
node admin-panel/onboarding.js
```

You will be asked about:
- Your platform name and type
- What kind of data it handles (PII, financial, health, public, etc.)
- What external APIs or services it connects to
- Whether agents need to write data or only read it
- How many agents you expect to run simultaneously

Your answers are saved to `config/platform.json` and used throughout the rest of setup.

---

## Step 3 — Run the Risk Scanner

Point the scanner at your project directory. It will analyze your codebase and config files and produce a risk profile.

```bash
node risk-scanner/scanner.js --target /path/to/your/project
```

Output is saved to `risk-scanner/output/risk-profile.json`

Review the output before moving on. The scanner will flag:
- Data exposure risks
- Overly broad API scopes
- Auth pattern gaps
- Conditions that could cause agent loops

---

## Step 4 — Review Your Guardrail Profile

Open `risk-scanner/output/risk-profile.json` and review what the scanner found. This file becomes the source for your guardrail agent's rules.

If you disagree with a finding or want to add something the scanner missed, edit the file directly before continuing. See [agents/guardrail/definition.md](../agents/guardrail/definition.md) for guidance.

---

## Step 5 — Activate Agents

Start the admin panel and activate the agents your platform needs.

```bash
node admin-panel/index.js
```

The admin panel runs at `http://localhost:3000` by default.

From there you can:
- Toggle agents on or off
- Upload updated markdown definitions
- View the current risk profile
- Check agent status and last activity

---

## Step 6 — Test Each Active Agent

Each agent folder contains a `test.md` file. Work through the checklist for every agent you activated before going to production.

Example:
```
agents/guardrail/test.md
agents/event-driven/test.md
```

---

## You're Ready

Once testing passes, your MCPBlueprint setup is ready to integrate into your platform. See the `/examples` folder for reference architectures showing how different platform types wire things together.
